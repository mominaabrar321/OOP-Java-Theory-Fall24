package marraylist;

import java.util.GregorianCalendar;
import java.util.Scanner;

public class MArrayList
{
    public static void main(String[] args)
    {
        MDirectory directory = new MDirectory();
        Scanner scanner = new Scanner(System.in);

        while (true)
        {
            System.out.println("\n--- Phone Directory Menu ---");
            System.out.println("1. Add Contact");
            System.out.println("2. Search Contact");
            System.out.println("3. Delete Contact");
            System.out.println("4. Replace a Number");
            System.out.println("5. Display All Contacts");
            System.out.println("6. Block a Number");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice)
            {
                case 1:
                {
                    System.out.print("Enter First Name: ");
                    String fName = scanner.nextLine();
                    System.out.print("Enter Last Name: ");
                    String lName = scanner.nextLine();
                    System.out.print("Enter Number of Phone Numbers: ");
                    int numberOfPhones = scanner.nextInt();
                    scanner.nextLine();
                    String[] phones = new String[numberOfPhones];
                    for (int i = 0; i < numberOfPhones; i++)
                    {
                        System.out.print("Enter Phone Number " + (i + 1) + ": ");
                        phones[i] = scanner.nextLine();
                    }
                    System.out.print("Enter Affiliation: ");
                    String affiliation = scanner.nextLine();
                    System.out.print("Enter Occupation: ");
                    String occupation = scanner.nextLine();
                    System.out.print("Enter Note: ");
                    String note = scanner.nextLine();
                    directory.addContact(fName, lName, phones, affiliation, occupation, note, new GregorianCalendar());
                    break;
                }
                case 2:
                {
                    System.out.print("Enter First Name to Search: ");
                    String fName = scanner.nextLine();
                    MContact contact = directory.searchContact(fName);
                    System.out.println((contact != null) ? contact : "Contact not found.");
                    break;
                }
                case 3:
                {
                    System.out.print("Enter First Name to Delete: ");
                    String fName = scanner.nextLine();
                    boolean isDeleted = directory.deleteContact(fName);
                    System.out.println(isDeleted ? "Contact deleted." : "Contact not found.");
                    break;
                }
                case 4:
                {
                    System.out.print("Enter First Name to Replace Number: ");
                    String fName = scanner.nextLine();
                    MContact contact = directory.searchContact(fName);
                    if (contact != null)
                    {
                        System.out.print("Enter Old Number: ");
                        String oldNum = scanner.nextLine();
                        System.out.print("Enter New Number: ");
                        String newNum = scanner.nextLine();
                        contact.replaceNumber(oldNum, newNum);
                        System.out.println("Number replaced successfully.");
                    }
                    else
                    {
                        System.out.println("Contact not found.");
                    }
                    break;
                }
                case 5:
                {
                    System.out.println(directory);
                    break;
                }
                case 6:
                {
                    System.out.print("Enter First Name to Block: ");
                    String fName = scanner.nextLine();
                    MContact contact = directory.searchContact(fName);
                    if (contact != null)
                    {
                        contact.setBlocked(true);
                        System.out.println("Contact blocked.");
                    }
                    else
                    {
                        System.out.println("Contact not found.");
                    }
                    break;
                }
                case 7:
                {
                    System.out.println("Exiting");
                    scanner.close();
                    return;
                }
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}