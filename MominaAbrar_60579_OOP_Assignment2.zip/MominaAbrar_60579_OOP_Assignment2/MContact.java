package marraylist;

import java.util.GregorianCalendar;

public class MContact
{
    private String fName, lName;
    private String[] phoneNum;
    private String affiliation;
    private String occupation;
    private String note = "";
    private GregorianCalendar dob;
    private boolean blocked = false;

    public MContact()
    {
    }

    public MContact(String fName, String lName, String[] phoneNum, String affiliation, 
                   String occupation, String note, GregorianCalendar dob)
    {
        this.fName = fName;
        this.lName = lName;
        this.phoneNum = phoneNum;
        this.affiliation = affiliation;
        this.occupation = occupation;
        this.note = note;
        this.dob = dob;
    }

    public MContact(String fName, String lName)
    {
        this.fName = fName;
        this.lName = lName;
    }
    
    public void setfName(String fName)
    {
        this.fName = fName;
    }
    public String getfName()
    {
        return fName;
    }
    
    public void setlName(String lName)
    {
        this.lName = lName;
    }
    public String getlName()
    {
        return lName;
    }
    
    public void setPhoneNum(String[] phoneNum)
    {
        this.phoneNum = phoneNum;
    }
    public String[] getPhoneNum()
    {
        return phoneNum;
    }
    
    public void setAffiliation(String affiliation)
    {
        this.affiliation = affiliation;
    }
    public String getAffiliation()
    {
        return affiliation;
    }
    
    public void setOccupation(String occupation)
    {
        this.occupation = occupation;
    }
    public String getOccupation()
    {
        return occupation;
    }
    
    public void setNote(String note)
    {
        this.note = note;
    }
    public String getNote()
    {
        return note;
    }
    
    public void setDob(GregorianCalendar dob)
    {
        this.dob = dob;
    }
    public GregorianCalendar getDob()
    {
        return dob;
    }
    
    public void setBlocked(boolean blocked)
    {
        this.blocked = blocked;
    }
    public boolean isBlocked()
    {
        return blocked;
    }

    public void replaceNumber(String oldNum, String newNum)
    {
        for (int i = 0; i < phoneNum.length; i++)
        {
            if (phoneNum[i].equals(oldNum))
            {
                phoneNum[i] = newNum;
                break;
            }
        }
    }

    @Override
    public String toString()
    {
        StringBuilder numbers = new StringBuilder();
        for (String num : phoneNum)
        {
            numbers.append(num).append(" ");
        }
        return "Contact{" + "First Name='" + fName + '\'' + ", Last Name='" + lName + '\'' + ", Phone Numbers=" + numbers.toString() + ", Affiliation='" + affiliation + '\'' + ", Occupation='" + occupation + '\'' + ", Note='" + note + '\'' + ", DOB=" + dob.getTime() + ", Blocked=" + blocked + '}';
    }
}