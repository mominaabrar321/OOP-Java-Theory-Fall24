package marraylist;

import java.util.ArrayList;
import java.util.GregorianCalendar;

public class MDirectory
{
    private ArrayList<MContact> directory;
    private int num;

    public MDirectory()
    {
        this.directory = new ArrayList<>();
    }

    public MDirectory(ArrayList<MContact> directory)
    {
        this.directory = directory;
    }

    public void addContact(MContact c)
    {
        directory.add(c);
        num++;
    }

    public void addContact(String fName, String lName, String[] phoneNum, String affiliation, 
                           String occupation, String note, GregorianCalendar dob)
    {
        MContact contact = new MContact(fName, lName, phoneNum, affiliation, occupation, note, dob);
        addContact(contact);
    }

    public MContact searchContact(String firstName)
    {
        for (MContact contact : directory)
        {
            if (contact.getfName().equalsIgnoreCase(firstName))
            {
                return contact;
            }
        }
        return null;
    }

    public boolean deleteContact(String firstName)
    {
        MContact contact = searchContact(firstName);
        if (contact != null)
        {
            directory.remove(contact);
            num--;
            return true;
        }
        return false;
    }

    @Override
    public String toString()
    {
        StringBuilder directoryInfo = new StringBuilder("Directory:\n");
        for (MContact contact : directory)
        {
            directoryInfo.append(contact.toString()).append("\n");
        }
        return directoryInfo.toString();
    }
}